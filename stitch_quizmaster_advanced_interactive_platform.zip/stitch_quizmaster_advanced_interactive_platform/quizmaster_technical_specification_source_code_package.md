# QuizMaster - Anti-Gravity Interactive Quiz Platform
## Project Overview
A modern, fully responsive SaaS-level Quiz Maker built with a Glassmorphic UI/UX.

## Frontend Architecture
- **Framework:** HTML5, CSS3 (Tailwind CSS for utility-first styling), Vanilla JavaScript.
- **Design System:** Lumina Quiz Logic ({{DATA:DESIGN_SYSTEM:DESIGN_SYSTEM_1}})
- **Key Screens:**
    - Homepage ({{DATA:SCREEN:SCREEN_4}})
    - Quiz Builder ({{DATA:SCREEN:SCREEN_5}})
    - Quiz Interface ({{DATA:SCREEN:SCREEN_2}})
    - Results & Analytics ({{DATA:SCREEN:SCREEN_6}})

## Backend Architecture
- **Runtime:** Node.js
- **Framework:** Express.js
- **Database:** MongoDB with Mongoose
- **Authentication:** JWT with bcryptjs (12 salt rounds)

## Database Schema (Mongoose)
```javascript
// User Schema
const UserSchema = new mongoose.Schema({
  name: { type: String, required: true },
  username: { type: String, required: true, unique: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  createdAt: { type: Date, default: Date.now }
});

// Quiz Schema
const QuizSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: String,
  category: String,
  difficulty: { type: String, enum: ['Easy', 'Medium', 'Hard'] },
  timeLimit: Number,
  creatorId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  questions: [{
    questionText: String,
    options: [String],
    correctAnswer: Number,
    explanation: String
  }]
});
```

## API Endpoints
- `POST /api/auth/register` - User Registration
- `POST /api/auth/login` - JWT Authentication
- `GET /api/quizzes` - List all quizzes
- `POST /api/quizzes` - Create new quiz
- `GET /api/quizzes/:id` - Fetch specific quiz
- `POST /api/results` - Submit quiz results

## Deployment Instructions
1. **Frontend:** Deploy to Vercel/Netlify.
2. **Backend:** Deploy to Railway/Render.
3. **Database:** MongoDB Atlas.
4. **Environment:** Set `MONGO_URI`, `JWT_SECRET`, and `PORT` in `.env`.
