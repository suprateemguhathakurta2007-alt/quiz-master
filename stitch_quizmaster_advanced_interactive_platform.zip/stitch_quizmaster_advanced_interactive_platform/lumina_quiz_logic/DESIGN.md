---
name: Lumina Quiz Logic
colors:
  surface: '#fef7ff'
  surface-dim: '#dfd7e6'
  surface-bright: '#fef7ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f9f1ff'
  surface-container: '#f3ebfa'
  surface-container-high: '#ede5f4'
  surface-container-highest: '#e8dfee'
  on-surface: '#1d1a24'
  on-surface-variant: '#4a4455'
  inverse-surface: '#332f39'
  inverse-on-surface: '#f6eefc'
  outline: '#7b7487'
  outline-variant: '#ccc3d8'
  surface-tint: '#732ee4'
  primary: '#630ed4'
  on-primary: '#ffffff'
  primary-container: '#7c3aed'
  on-primary-container: '#ede0ff'
  inverse-primary: '#d2bbff'
  secondary: '#0051d5'
  on-secondary: '#ffffff'
  secondary-container: '#316bf3'
  on-secondary-container: '#fefcff'
  tertiary: '#00566b'
  on-tertiary: '#ffffff'
  tertiary-container: '#00708a'
  on-tertiary-container: '#c0edff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#eaddff'
  primary-fixed-dim: '#d2bbff'
  on-primary-fixed: '#25005a'
  on-primary-fixed-variant: '#5a00c6'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b4c5ff'
  on-secondary-fixed: '#00174b'
  on-secondary-fixed-variant: '#003ea8'
  tertiary-fixed: '#b7eaff'
  tertiary-fixed-dim: '#6cd3f7'
  on-tertiary-fixed: '#001f28'
  on-tertiary-fixed-variant: '#004e61'
  background: '#fef7ff'
  on-background: '#1d1a24'
  surface-variant: '#e8dfee'
typography:
  display-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 64px
    fontWeight: '800'
    lineHeight: 72px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '300'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-padding: 24px
  gutter: 16px
  section-gap: 48px
  glass-padding: 32px
---

## Brand & Style

This design system is built around the concept of "Cognitive Clarity"—a high-fidelity SaaS aesthetic that balances professional reliability with the energetic spark of interactive learning. The brand personality is intelligent, fast-paced, and aspirational.

The visual direction utilizes **Glassmorphism** to create a sense of "anti-gravity." UI elements should feel as if they are floating in a multi-dimensional space, using depth and translucency to reduce visual clutter. This approach ensures that even complex quiz data feels lightweight and accessible. The style combines modern minimalism with vibrant, energetic accents to keep users engaged during high-stakes testing or casual learning.

## Colors

The palette is anchored by **Vivid Violet** (#7c3aed), representing intelligence and creativity. This is supported by a spectrum of **Electric Blue** and **Deep Cyan** to reinforce a trustworthy, tech-forward SaaS feel. **Hot Pink** is reserved for high-impact accents, such as "Correct" celebrations or streak indicators.

To achieve the "anti-gravity" feel, the background should use a subtle mesh gradient of the primary and secondary colors at extremely low opacity (2-5%) against a nearly white neutral base. Surfaces are not solid; they are semi-transparent "glass" layers that allow these soft background hues to bleed through.

## Typography

The design system uses **Plus Jakarta Sans** across all levels to maintain a contemporary, geometric, and friendly tone. 

- **Weight Strategy:** Use `800` (ExtraBold) for display titles to create impact. Use `300` (Light) for secondary labels to enhance the "airy" feel of the UI.
- **Interactivity:** Questions should always be rendered in `headline-md` or `headline-lg` to ensure maximum readability during timed sessions.
- **Readability:** Body text uses a generous line height (1.5x) to prevent cognitive fatigue.

## Layout & Spacing

The layout follows a **Fluid Grid** system with a focus on centered, focused content containers. 

- **Desktop:** 12-column grid with 24px margins. Content is often grouped into "floating" glass modules that span 6 or 8 columns to maintain focus.
- **Mobile:** 4-column grid with 16px margins.
- **Rhythm:** An 8px linear scale governs all padding and margins. Vertical rhythm is critical; use `section-gap` (48px) to separate distinct quiz phases (e.g., Header, Question Area, Progress Bar).
- **Safe Areas:** Interactive components (buttons/inputs) must have a minimum hit area of 44px, but visually should utilize `glass-padding` (32px) for internal whitespace to maintain the premium SaaS aesthetic.

## Elevation & Depth

Depth in this design system is achieved through **multi-layered glassmorphism** rather than traditional heavy shadows.

1.  **Backdrop Blur:** All primary containers must use a `backdrop-filter: blur(12px)`. This creates the "frosted glass" effect.
2.  **Specular Highlights:** Instead of dark borders, use 1px solid internal strokes with a linear gradient (Top-Left: White 40% opacity to Bottom-Right: White 10% opacity). This simulates light hitting the edge of a physical glass pane.
3.  **Ambient Shadows:** Use "Tinted Shadows." Shadows should not be black; use a low-opacity version of the Primary Purple or Secondary Blue (e.g., `rgba(124, 58, 237, 0.1)`) with a large blur radius (30px+) and 0 spread to make elements appear to float effortlessly.

## Shapes

The shape language is consistently **Rounded** (0.5rem base) to evoke a friendly and modern personality. 

- **Modules:** Main quiz cards and glass containers use `rounded-xl` (1.5rem) to soften the large surface areas.
- **Interactions:** Buttons and input fields use `rounded-lg` (1.0rem) to distinguish them as actionable units.
- **Progress Elements:** Progress bars and "streak" badges should use pill-shaped rounding for a more organic, dynamic feel.

## Components

### Buttons & Inputs
- **Primary Action:** Use a linear gradient (Primary Purple to Secondary Blue) with a subtle "inner glow" border. On hover, increase the blur radius of the tinted shadow to simulate the button "rising."
- **Glass Input:** Inputs should be semi-transparent with a 1px specular border. On focus, the border should glow with the Tertiary Cyan color.

### Quiz Specifics
- **Question Cards:** High-blur glass containers. The question text should be high-contrast, while the background remains ethereal.
- **Chips/Badges:** Use "vibrant glass"—semi-transparent backgrounds tinted with the Category color (e.g., Science = Cyan tint, History = Purple tint).
- **Progress Bar:** A dual-layer track. The background is a "hollow" glass tube, and the fill is a vibrant, animated gradient that "pulses" as it fills.

### Micro-interactions
- Use "Spring" animations (e.g., `stiffness: 300, damping: 20`) for all glass cards appearing on screen.
- Icons should use Font Awesome 6 "Light" or "Thin" weights to match the delicate specular borders of the glass containers.